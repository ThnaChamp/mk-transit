MK Transit is a group project for CPE112 [ Programming with Data Structures ] Class.
